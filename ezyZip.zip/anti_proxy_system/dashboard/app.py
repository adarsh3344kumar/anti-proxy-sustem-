"""
Admin Dashboard - Web Interface
VGU Anti-Proxy Detection System

Features:
- View recent detection logs
- View system statistics
- Manual IP blocking/allow (for future enhancement)
- Real-time dashboard

Usage:
    python app.py
    
Then open: http://localhost:5000
"""

# Using built-in HTTP server instead of Flask for Python 3.14 compatibility
import http.server
import socketserver
import json
import csv
import os
from datetime import datetime
from urllib.parse import urlparse, parse_qs

# Path to logs file (relative to dashboard folder)
LOG_FILE = "../data/logs.csv"


def read_logs(limit=50):
    """
    Read logs from CSV file
    
    Args:
        limit (int): Number of recent logs to return
    
    Returns:
        list: List of log entries
    """
    if not os.path.exists(LOG_FILE):
        return []
    
    try:
        with open(LOG_FILE, "r") as file:
            reader = csv.reader(file)
            all_logs = list(reader)
        
        # Skip header and get last N entries
        if len(all_logs) > 1:
            return all_logs[-limit-1:]  # Include header
        return all_logs
    
    except Exception as e:
        print(f"Error reading logs: {e}")
        return []


def get_statistics():
    """
    Calculate system statistics
    
    Returns:
        dict: Statistics dictionary
    """
    logs = read_logs(limit=10000)
    
    if len(logs) <= 1:  # Only header or empty
        return {
            "total_events": 0,
            "proxy_detected": 0,
            "normal_traffic": 0,
            "detection_rate": "0%"
        }
    
    # Skip header row
    data_logs = logs[1:]
    
    proxy_count = sum(1 for log in data_logs if len(log) > 4 and "PROXY" in str(log[4]))
    total = len(data_logs)
    normal_count = total - proxy_count
    
    stats = {
        "total_events": total,
        "proxy_detected": proxy_count,
        "normal_traffic": normal_count,
        "detection_rate": f"{(proxy_count/total*100):.2f}%" if total > 0 else "0%"
    }
    
    return stats


class DashboardHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP Request Handler for Dashboard"""
    
    def do_GET(self):
        """Handle GET requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # API endpoints
        if path == '/api/logs':
            self.send_json_response(read_logs(limit=50))
        
        elif path == '/api/stats':
            self.send_json_response(get_statistics())
        
        elif path == '/api/alerts':
            alerts = self.get_alerts()
            self.send_json_response(alerts)
        
        elif path == '/' or path == '/dashboard':
            self.send_dashboard_html()
        
        else:
            self.send_error(404, "Not Found")
    
    def get_alerts(self):
        """Get recent proxy alerts"""
        logs = read_logs(limit=100)
        alerts = []
        
        if len(logs) > 1:
            for log in logs[1:]:
                if len(log) > 4 and "PROXY" in str(log[4]):
                    alerts.append({
                        "timestamp": log[0] if len(log) > 0 else "",
                        "source_ip": log[1] if len(log) > 1 else "",
                        "dest_ip": log[2] if len(log) > 2 else "",
                        "protocol": log[3] if len(log) > 3 else "",
                        "status": log[4] if len(log) > 4 else "",
                        "risk_score": log[5] if len(log) > 5 else "0"
                    })
        
        return alerts
    
    def send_json_response(self, data):
        """Send JSON response"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())
    
    def send_dashboard_html(self):
        """Send dashboard HTML"""
        logs = read_logs(limit=50)
        stats = get_statistics()
        
        # Build HTML with data
        html = self.build_html(logs, stats)
        
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html.encode())
    
    def build_html(self, logs, stats):
        """Build dashboard HTML"""
        # Build logs table
        logs_html = "<tr><th>Time</th><th>Source IP</th><th>Dest IP</th><th>Protocol</th><th>Status</th><th>Risk</th><th>Reason</th></tr>"
        
        if logs and len(logs) > 1:
            for log in logs[1:]:
                status_badge = '<span style="background:#d4edda;color:#155724;padding:4px 8px;border-radius:3px;font-size:12px;">'
                
                if len(log) > 4 and "PROXY" in log[4]:
                    status_badge += "🚨 PROXY/VPN"
                else:
                    status_badge += "✓ NORMAL"
                
                status_badge += "</span>"
                
                log_row = f"<tr>"
                log_row += f"<td>{log[0] if len(log) > 0 else ''}</td>"
                log_row += f"<td><code>{log[1][:16] if len(log) > 1 else ''}...</code></td>"
                log_row += f"<td><code>{log[2][:16] if len(log) > 2 else ''}...</code></td>"
                log_row += f"<td>{log[3] if len(log) > 3 else ''}</td>"
                log_row += f"<td>{status_badge}</td>"
                log_row += f"<td>{log[5] if len(log) > 5 else '0'}</td>"
                log_row += f"<td>{log[6] if len(log) > 6 else ''}</td>"
                log_row += f"</tr>"
                
                logs_html += log_row
        
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>VGU Anti-Proxy Detection Dashboard</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        
        header {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        
        header h1 {{
            color: #333;
            margin-bottom: 5px;
        }}
        
        .stats {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }}
        
        .stat-card {{
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }}
        
        .stat-card h3 {{
            color: #666;
            font-size: 12px;
            margin-bottom: 10px;
        }}
        
        .stat-card .number {{
            font-size: 28px;
            font-weight: bold;
            color: #667eea;
        }}
        
        .logs {{
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        
        table th {{
            background: #f0f0f0;
            padding: 10px;
            text-align: left;
            font-size: 12px;
            border-bottom: 1px solid #ddd;
        }}
        
        table td {{
            padding: 10px;
            border-bottom: 1px solid #eee;
            font-size: 12px;
        }}
        
        table tr:hover {{
            background: #f9f9f9;
        }}
        
        code {{
            background: #f5f5f5;
            padding: 2px 4px;
            border-radius: 3px;
            font-family: monospace;
        }}
        
        .footer {{
            text-align: center;
            color: white;
            margin-top: 20px;
            font-size: 12px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🛡️ VGU Anti-Proxy Detection System</h1>
            <p>Vivekananda Global University - Network Security Monitoring Dashboard</p>
        </header>
        
        <div class="stats">
            <div class="stat-card">
                <h3>Total Events</h3>
                <div class="number">{stats['total_events']}</div>
            </div>
            <div class="stat-card">
                <h3>Proxy Detected</h3>
                <div class="number" style="color:#e74c3c;">{stats['proxy_detected']}</div>
            </div>
            <div class="stat-card">
                <h3>Normal Traffic</h3>
                <div class="number" style="color:#27ae60;">{stats['normal_traffic']}</div>
            </div>
            <div class="stat-card">
                <h3>Detection Rate</h3>
                <div class="number">{stats['detection_rate']}</div>
            </div>
        </div>
        
        <div class="logs">
            <h2>📊 Detection Logs</h2>
            <table>
                {logs_html}
            </table>
        </div>
        
        <div class="footer">
            <p>VGU Anti-Proxy Detection System v1.0 | Educational Lab Environment | 2024</p>
        </div>
    </div>
</body>
</html>
        """
        
        return html
    
    def log_message(self, format, *args):
        """Suppress default log messages"""
        pass


if __name__ == "__main__":
    port = 5000
    
    print("=" * 70)
    print("  VGU Anti-Proxy Detection Dashboard")
    print("=" * 70)
    print()
    print("  Starting HTTP server...")
    print(f"  Dashboard URL: http://localhost:{port}")
    print()
    print("  Press Ctrl+C to stop")
    print()
    
    handler = DashboardHandler
    with socketserver.TCPServer(("", port), handler) as httpd:
        print(f"✓ Server running on http://localhost:{port}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\n[!] Server stopped by user")
            print("✓ Shutdown complete")


# OLD FLASK CODE - Kept for reference
# @app.route("/")
# def dashboard():
#     logs = read_logs(limit=50)
#     stats = get_statistics()
#     return render_template("dashboard.html", logs=logs, stats=stats)
#
# @app.route("/api/logs")
# def api_logs():
#     limit = request.args.get("limit", 50, type=int)
#     logs = read_logs(limit=limit)
#     json_logs = []
#     if len(logs) > 1:
#         headers = logs[0]
#         for log in logs[1:]:
#             log_dict = {}
#             for i, header in enumerate(headers):
#                 log_dict[header] = log[i] if i < len(log) else ""
#             json_logs.append(log_dict)
#     return jsonify(json_logs)
#
# @app.route("/api/stats")
# def api_stats():
#     return jsonify(get_statistics())
#
# @app.route("/api/alerts")
# def api_alerts():
#     logs = read_logs(limit=100)
#     alerts = []
#     if len(logs) > 1:
#         for log in logs[1:]:
#             if len(log) > 4 and "PROXY" in str(log[4]):
#                 alerts.append({
#                     "timestamp": log[0] if len(log) > 0 else "",
#                     "source_ip": log[1] if len(log) > 1 else "",
#                     "dest_ip": log[2] if len(log) > 2 else "",
#                     "protocol": log[3] if len(log) > 3 else "",
#                     "status": log[4] if len(log) > 4 else "",
#                     "risk_score": log[5] if len(log) > 5 else "0"
#                 })
#     return jsonify(alerts)
#
# if __name__ == "__main__":
#     print("=" * 70)
#     print("  VGU Anti-Proxy Detection Dashboard")
#     print("=" * 70)
#     print()
#     print("  Starting Flask server...")
#     print("  Dashboard URL: http://localhost:5000")
#     print()
#     print("  Press Ctrl+C to stop")
#     print()
#     app.run(debug=True, host="127.0.0.1", port=5000)
