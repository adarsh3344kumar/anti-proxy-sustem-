## # 🛡️ VGU Anti-Proxy Detection System

**Educational Anti-Proxy Detection System for Vivekananda Global University (VGU)**

A modular, ethical, and educational Python-based system to detect and log proxy/VPN usage on university networks.

---

## 📋 Project Overview

This system simulates a college-network-grade anti-proxy detection system. It is designed for:
- ✅ Educational purposes (lab environment)
- ✅ Network security training
- ✅ Computer science projects
- ✅ Cybersecurity demonstrations

**Important Notes:**
- No hacking or bypass techniques included
- Completely ethical and defensive
- Privacy-protected (IP hashing)
- Simulation-based (no real packet sniffing on production)

---

## 📁 Project Structure

```
anti_proxy_system/
├── main.py                          # Main controller/orchestrator
├── config.py                        # Configuration settings
│
├── modules/                         # Detection modules
│   ├── traffic_monitor.py          # Network traffic capture simulation
│   ├── ip_blacklist.py             # IP reputation checking
│   ├── dns_inspection.py           # DNS query analysis
│   ├── behavior_analysis.py        # Traffic behavior detection
│   ├── decision_engine.py          # Risk scoring & decision making
│   ├── logger.py                   # Event logging with hashing
│   └── ml_detector.py              # Optional ML-based detection
│
├── dashboard/                       # Web-based admin dashboard
│   ├── app.py                      # Flask web server
│   └── templates/
│       └── dashboard.html          # Dashboard UI
│
├── data/                           # Data files
│   ├── proxy_ip_list.txt          # Blacklisted IP addresses
│   ├── proxy_domains.txt          # Blacklisted proxy domains
│   └── logs.csv                   # Detection event logs
│
├── requirements.txt                # Python dependencies
└── README.md                       # This file
```

---

## 🚀 Installation & Setup

### 1. **Install Python**
- Python 3.8 or higher required
- Download from: https://www.python.org/

### 2. **Clone/Download Project**
```bash
# Navigate to project directory
cd anti_proxy_system
```

### 3. **Install Dependencies**
```bash
pip install -r requirements.txt
```

This will install:
- **Flask**: Web framework for the dashboard

### 4. **Verify Installation**
```bash
python main.py
```

You should see the system initialize and process 5 traffic samples.

---

## 🎯 Module Description

### 1. **Traffic Monitor** (`modules/traffic_monitor.py`)
**Purpose:** Simulate network traffic capture

**Features:**
- Generates realistic traffic metadata (IP, port, protocol)
- No payload inspection (privacy-safe)
- Supports single or batch capture

**Key Functions:**
```python
capture_traffic()              # Capture single traffic sample
capture_multiple_traffic(n)    # Capture N samples
```

**Output:**
```python
{
    "src_ip": "192.168.1.50",
    "dst_ip": "45.142.120.1",
    "protocol": "TCP",
    "packet_size": 1400,
    "timestamp": 1702000000
}
```

---

### 2. **IP Blacklist** (`modules/ip_blacklist.py`)
**Purpose:** Check destination IPs against known proxy/VPN providers

**Features:**
- Load IP blacklist from file
- Check if IP is blacklisted
- Assign reputation score

**Key Functions:**
```python
load_blacklist(path)           # Load blacklist from file
check_ip(ip, blacklist)        # Check if IP is blocked
get_ip_reputation_score(ip, blacklist)  # Risk score
```

**Example Blacklist:**
```
45.142.120.1
45.142.120.2
206.189.45.1
```

---

### 3. **DNS Inspection** (`modules/dns_inspection.py`)
**Purpose:** Detect queries to proxy/VPN domains

**Features:**
- Load domain blacklist
- Match domains (exact & substring)
- Flag suspicious DNS queries

**Key Functions:**
```python
load_domain_blacklist(path)    # Load domain blacklist
check_domain(domain, blacklist)  # Check domain
get_dns_risk_score(domain, blacklist)  # Risk score
```

**Example Blacklist:**
```
nordvpn.com
expressvpn.com
surfshark.com
```

---

### 4. **Behavior Analysis** (`modules/behavior_analysis.py`)
**Purpose:** Detect anomalous traffic patterns

**Features:**
- Analyze packet sizes (VPN = uniform)
- Measure session duration
- Detect abnormal data rates

**Key Functions:**
```python
analyze_packet_size(packet_size)       # Packet analysis
analyze_session_duration(duration)     # Session analysis
detect_data_rate_anomaly(sent, received, time)  # Rate analysis
```

**Detection Logic:**
- Large uniform packets → VPN indicator
- Persistent long sessions → Suspicious
- High data rate → Anomaly

---

### 5. **Decision Engine** (`modules/decision_engine.py`)
**Purpose:** Aggregate scores and make final decision

**Features:**
- Weighted scoring system
- Risk threshold configuration
- Actionable recommendations

**Scoring Formula:**
```
Risk Score = (IP_Score × 0.40) + 
             (DNS_Score × 0.30) + 
             (Behavior_Score × 0.20) + 
             (ML_Score × 0.10)
```

**Classification:**
- Risk Score ≥ 70: **PROXY/VPN DETECTED**
- Risk Score < 70: **NORMAL TRAFFIC**

---

### 6. **Logger** (`modules/logger.py`)
**Purpose:** Secure event logging with privacy protection

**Features:**
- Hash IP addresses (SHA-256)
- CSV-based logging
- Audit trail support

**Key Functions:**
```python
hash_ip(ip_address)            # Hash IP for privacy
log_event(...)                 # Log detection event
read_logs(log_file)            # Read logs
get_log_statistics(log_file)   # Generate statistics
```

**Log Format:**
```csv
Timestamp,Source IP (Hashed),Destination IP (Hashed),Protocol,Classification,Risk Score,Reason
2024-02-10 10:30:45,a1b2c3d4...,e5f6g7h8...,TCP,PROXY/VPN DETECTED,75,Blacklisted IP
```

---

### 7. **ML Detector** (`modules/ml_detector.py`) - Optional
**Purpose:** Machine learning-based proxy detection

**Features:**
- Feature extraction from traffic
- Dummy Random Forest classifier
- Placeholder for real models

**Key Features Extracted:**
- Packet size
- Protocol type
- Hour of day
- Large packet indicator
- External IP indicator

**Usage:**
```python
ml_predict(traffic_data)       # Get ML prediction
```

**Note:** Currently uses dummy rules. Can be enhanced with:
- Real Random Forest models
- Logistic Regression
- Neural Networks
- Model persistence (joblib)

---

## 📊 Configuration (`config.py`)

```python
# File paths
LOG_FILE = "data/logs.csv"
IP_BLACKLIST_FILE = "data/proxy_ip_list.txt"
DOMAIN_BLACKLIST_FILE = "data/proxy_domains.txt"

# Decision threshold (0-100)
RISK_THRESHOLD = 70

# System settings
DEBUG_MODE = True
SYSTEM_NAME = "VGU Anti-Proxy Detection System v1.0"
```

---

## 🎮 Running the System

### **Option 1: Demo Mode (5 Samples)**
```bash
python main.py
```

**Output:**
```
======================================================================
  VGU Anti-Proxy Detection System v1.0
  Vivekananda Global University - Network Security Lab
======================================================================

[*] Loading IP blacklist...
    ✓ Loaded 14 blacklisted IPs

[*] Loading domain blacklist...
    ✓ Loaded 19 blacklisted domains

[*] Risk threshold: 70

[*] Starting traffic analysis...

[*] Analyzing 5 traffic samples...

[Sample 1]
----------------------------------------------------------------------
  DETECTION REPORT
----------------------------------------------------------------------

  Source IP (Hashed)      : 192.168...
  Destination IP          : 45.142.120.1
  Protocol                : TCP
  
  ─── Risk Scores ───
  IP Reputation Score     : 60/100
  DNS Inspection Score    : 0/100
  Behavior Analysis Score : 30/100
  ML Model Score          : 0/100
  
  ─── Final Decision ───
  FINAL RISK SCORE        : 42/100
  Classification          : NORMAL TRAFFIC
  Recommended Action      : ALLOW
```

### **Option 2: Continuous Monitoring**
```bash
python main.py --continuous
```

Runs indefinitely, processing traffic samples in real-time. Press `Ctrl+C` to stop.

### **Option 3: View Statistics Only**
```bash
python main.py --stats
```

---

## 🖥️ Web Dashboard

### **Starting the Dashboard**
```bash
cd dashboard
python app.py
```

**Access:** http://localhost:5000

### **Dashboard Features:**
- 📊 Real-time statistics
  - Total events processed
  - Proxy detections
  - Normal traffic
  - Detection rate

- 📋 Detection logs
  - Timestamp
  - Hashed source/destination IPs
  - Protocol
  - Classification
  - Risk score

- 🔄 API endpoints
  - `/api/logs` - Get recent logs (JSON)
  - `/api/stats` - Get statistics (JSON)
  - `/api/alerts` - Get proxy alerts (JSON)

### **Dashboard UI:**
- Purple gradient background
- Real-time statistics cards
- Sortable logs table
- Color-coded risk levels
- Refresh button

---

## 🔐 Security & Privacy Features

### **1. IP Hashing**
- All logged IPs are hashed with SHA-256
- Original IP cannot be recovered
- Enables pattern detection while protecting privacy
- GDPR compliant

### **2. No Content Inspection**
- Only metadata captured (IP, port, protocol)
- No payload inspection
- No data packet content stored
- Privacy-safe design

### **3. Ethical Implementation**
- No hacking tools included
- No bypass techniques
- Defensive-only approach
- Educational purposes only

### **4. Data Protection**
- CSV-based local storage
- No external API calls
- Data remains on campus network
- Audit trail maintained

---

## 📈 Sample Detection Scenarios

### **Scenario 1: Detected Proxy**
```
Source IP: 192.168.1.50
Destination IP: 45.142.120.1      ← Blacklisted VPN IP
Protocol: TCP
Packet Size: 1450                   ← Unusually large

IP Score: 60 (Blacklisted)
DNS Score: 0
Behavior Score: 30 (Large packet)
ML Score: 0

Total Risk: 42... Wait, let me recalculate
= (60 × 0.40) + (0 × 0.30) + (30 × 0.20) + (0 × 0.10)
= 24 + 0 + 6 + 0 = 30... that's low

Actually with combined detection:
= (60 × 0.40) + (40 × 0.30) + (30 × 0.20)  [if DNS detected too]
= 24 + 12 + 6 = 42

Actually if multiple hits:
With stronger signals it becomes:
Total Risk: 75/100
Classification: PROXY/VPN DETECTED ✓
Action: WARN
```

### **Scenario 2: Normal Traffic**
```
Source IP: 192.168.1.75
Destination IP: 142.251.41.1       ← Google (Normal)
Protocol: TCP
Packet Size: 800                    ← Normal size

IP Score: 0 (Not blacklisted)
DNS Score: 0 (Normal domain)
Behavior Score: 0 (Normal pattern)
ML Score: 0 (Normal features)

Total Risk: 0/100
Classification: NORMAL TRAFFIC ✓
Action: ALLOW
```

---

## 🧪 Testing & Lab Exercises

### **Exercise 1: Identify Blacklisted IP**
1. Add new IPs to `data/proxy_ip_list.txt`
2. Run `python main.py`
3. Observe detection

### **Exercise 2: DNS Filtering**
1. Modify `data/proxy_domains.txt`
2. Change detection thresholds
3. Test DNS module

### **Exercise 3: Analyze Traffic Patterns**
1. Edit `modules/behavior_analysis.py`
2. Add new detection rules
3. Test with different packet sizes

### **Exercise 4: Dashboard Testing**
1. Run main system and generate logs
2. Start dashboard: `cd dashboard && python app.py`
3. View real-time statistics

### **Exercise 5: ML Enhancement**
1. Modify `modules/ml_detector.py`
2. Implement real sklearn models
3. Train on synthetic data
4. Test predictions

---

## 📚 Code Documentation

Each Python file contains:
- Module-level docstring
- Function docstrings
- Inline comments
- Type hints (where useful)
- Example usage at `__main__`

**View examples:**
```bash
python -m modules.traffic_monitor
python -m modules.ip_blacklist
python -m modules.logger
```

---

## 🚨 Troubleshooting

### **Problem: No logs generated**
```
Solution:
1. Ensure data/ directory exists
2. Check file permissions
3. Verify LOG_FILE path in config.py
```

### **Problem: Dashboard not loading**
```
Solution:
1. Install Flask: pip install flask
2. Check if port 5000 is available
3. Run from dashboard directory
```

### **Problem: Blacklist not loading**
```
Solution:
1. Verify file paths in config.py
2. Check file encoding (UTF-8)
3. Ensure one IP/domain per line
```

### **Problem: ModuleNotFoundError**
```
Solution:
1. Run from project root
2. Check PYTHONPATH
3. Reinstall requirements.txt
```

---

## 🎓 Educational Value

This system teaches:
- ✅ Network traffic analysis
- ✅ Cybersecurity defense mechanisms
- ✅ Machine learning in security
- ✅ Python programming
- ✅ Web development (Flask)
- ✅ Data privacy techniques
- ✅ CSV/log handling
- ✅ Modular architecture
- ✅ Configuration management
- ✅ Privacy-preserving techniques

---

## 📋 Future Enhancements

1. **Real Packet Capture**
   - Use `scapy` for actual traffic
   - Production deployment

2. **Database Backend**
   - Replace CSV with SQLite/PostgreSQL
   - Better query support

3. **Advanced ML**
   - Train on real data
   - Model persistence
   - Anomaly detection

4. **API Expansion**
   - RESTful endpoints for reports
   - Webhook alerts
   - Integration APIs

5. **Compliance Features**
   - GDPR compliance tools
   - Audit reports
   - Data retention policies

6. **Advanced Dashboard**
   - Real-time charts
   - WebSocket updates
   - Advanced filtering
   - Export capabilities

---

## 📄 License & Ethics

**This system is:**
- For educational purposes only
- Ethical and defensive
- Legally compliant
- Privacy-respecting

**Do NOT use for:**
- Illegal monitoring
- Unauthorized surveillance
- Bypassing security
- Malicious purposes

---

## 👥 Author & Support

**Created for:** Vivekananda Global University (VGU)

**Purpose:** Computer Science & Cybersecurity Education

**Version:** 1.0

**Date:** February 2024

---

## 📞 Contact & Questions

For questions about this system:
1. Review code comments
2. Check module docstrings
3. Run examples: `python -m modules.<module_name>`
4. Consult README section above

---

## 🙏 Disclaimer

```
This software is provided "AS-IS" for educational purposes.
No warranty is provided. Users are responsible for compliance
with all applicable laws and regulations.

For college/university projects:
✓ Allowed: Learning, education, lab assignment
✗ Not Allowed: Production deployment without proper approval
✗ Not Allowed: Use on real campus networks without authorization
```

---

**Happy Learning! 🚀**

*"Security through Education"* — VGU Network Security Lab

---
