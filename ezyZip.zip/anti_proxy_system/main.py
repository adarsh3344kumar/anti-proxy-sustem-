"""
Main Controller - Anti-Proxy Detection System
Vivekananda Global University (VGU)

This is the main entry point for the system
It orchestrates all modules and coordinates the detection process

Usage:
    python main.py

This will:
1. Capture simulated network traffic
2. Check IP against blacklist
3. Analyze DNS queries
4. Analyze traffic behavior
5. Make detection decision
6. Log results with privacy protection
"""

import sys
from datetime import datetime

# Import all modules
from modules.traffic_monitor import capture_traffic, capture_multiple_traffic
from modules.ip_blacklist import load_blacklist, check_ip, get_ip_reputation_score
from modules.dns_inspection import load_domain_blacklist, check_domain, get_dns_risk_score
from modules.behavior_analysis import analyze_packet_size, analyze_traffic_pattern
from modules.decision_engine import calculate_risk_score, decide_traffic_classification, generate_decision_report
from modules.logger import write_log_entry, read_logs, get_log_statistics
from modules.ml_detector import ml_predict

from config import *


def initialize_system():
    """
    Initialize the anti-proxy detection system
    
    - Load configuration
    - Load blacklists
    - Prepare logging
    
    Returns:
        tuple: (ip_blacklist, domain_blacklist)
    """
    print("=" * 70)
    print(f"  {SYSTEM_NAME}")
    print("  Vivekananda Global University - Network Security Lab")
    print("=" * 70)
    print()
    
    # Load blacklists
    print("[*] Loading IP blacklist...")
    ip_blacklist = load_blacklist(IP_BLACKLIST_FILE)
    print(f"    ✓ Loaded {len(ip_blacklist)} blacklisted IPs")
    
    print("[*] Loading domain blacklist...")
    domain_blacklist = load_domain_blacklist(DOMAIN_BLACKLIST_FILE)
    print(f"    ✓ Loaded {len(domain_blacklist)} blacklisted domains")
    
    print(f"[*] Risk threshold: {RISK_THRESHOLD}")
    print()
    
    return ip_blacklist, domain_blacklist


def process_traffic(traffic_data, ip_blacklist, domain_blacklist, sample_domain=""):
    """
    Process a single traffic sample through all detection modules
    
    Args:
        traffic_data (dict): Traffic metadata
        ip_blacklist (list): Blacklisted IPs
        domain_blacklist (list): Blacklisted domains
        sample_domain (str): Sample domain for DNS check
    
    Returns:
        dict: Detection results and decision
    """
    
    # Module 1: IP Reputation Check
    ip_score = get_ip_reputation_score(traffic_data["dst_ip"], ip_blacklist)
    
    # Module 2: DNS Inspection
    dns_score = get_dns_risk_score(sample_domain, domain_blacklist)
    
    # Module 3: Behavior Analysis
    behavior_score = analyze_packet_size(traffic_data["packet_size"])
    
    # Module 4: ML Detection (optional)
    ml_score = ml_predict(traffic_data) // 2  # Scale down to 0-50 range
    
    # Module 5: Decision Engine
    risk_score = calculate_risk_score(ip_score, dns_score, behavior_score, ml_score)
    classification = decide_traffic_classification(risk_score, RISK_THRESHOLD)
    
    # Generate detailed report
    report = generate_decision_report(
        traffic_data,
        {
            "ip_score": ip_score,
            "dns_score": dns_score,
            "behavior_score": behavior_score,
            "ml_score": ml_score
        },
        risk_score,
        RISK_THRESHOLD
    )
    
    # Module 6: Logging
    write_log_entry(
        LOG_FILE,
        traffic_data["src_ip"],
        traffic_data["dst_ip"],
        traffic_data["protocol"],
        classification,
        risk_score,
        ""
    )
    
    return report


def display_report(report):
    """
    Display detection report in formatted output
    
    Args:
        report (dict): Detection report
    """
    print("-" * 70)
    print(f"  DETECTION REPORT")
    print("-" * 70)
    print()
    print(f"  Source IP (Hashed)      : {report['source_ip'][:8]}...")
    print(f"  Destination IP          : {report['destination_ip']}")
    print(f"  Protocol                : {report['protocol']}")
    print()
    print(f"  ─── Risk Scores ───")
    print(f"  IP Reputation Score     : {report['ip_score']}/100")
    print(f"  DNS Inspection Score    : {report['dns_score']}/100")
    print(f"  Behavior Analysis Score : {report['behavior_score']}/100")
    print(f"  ML Model Score          : {report['ml_score']}/100")
    print()
    print(f"  ─── Final Decision ───")
    print(f"  FINAL RISK SCORE        : {report['final_risk_score']}/100")
    print(f"  Classification          : {report['classification']}")
    print(f"  Recommended Action      : {report['action']}")
    print()


def show_statistics():
    """
    Show statistics from logs
    """
    stats = get_log_statistics(LOG_FILE)
    
    print("-" * 70)
    print(f"  SYSTEM STATISTICS")
    print("-" * 70)
    print()
    print(f"  Total Events Processed  : {stats['total_events']}")
    print(f"  Proxy/VPN Detected      : {stats['proxy_detected']}")
    print(f"  Normal Traffic          : {stats['normal_traffic']}")
    print(f"  Detection Rate          : {stats['detection_rate']}")
    print()


def run_demo():
    """
    Run a demo analysis on sample traffic
    """
    # Initialize system
    ip_blacklist, domain_blacklist = initialize_system()
    
    print("[*] Starting traffic analysis...")
    print()
    
    # Sample domain for DNS check
    sample_domains = ["nordvpn.com", "expressvpn.com", "youtube.com", "google.com"]
    
    # Process multiple traffic samples
    num_samples = 5
    
    print(f"[*] Analyzing {num_samples} traffic samples...")
    print()
    
    for i in range(num_samples):
        traffic = capture_traffic()
        sample_domain = sample_domains[i % len(sample_domains)]
        
        report = process_traffic(traffic, ip_blacklist, domain_blacklist, sample_domain)
        
        print(f"[Sample {i+1}]")
        display_report(report)
    
    # Show statistics
    show_statistics()
    
    print("[✓] Analysis complete!")
    print()


def run_continuous_monitoring(duration=60):
    """
    Run continuous traffic monitoring
    
    Args:
        duration (int): Monitoring duration in seconds
    """
    import time
    
    ip_blacklist, domain_blacklist = initialize_system()
    
    print("[*] Starting continuous monitoring (press Ctrl+C to stop)...")
    print()
    
    sample_domains = ["nordvpn.com", "expressvpn.com", "youtube.com", "google.com"]
    count = 0
    
    try:
        start_time = time.time()
        
        while True:
            traffic = capture_traffic()
            sample_domain = sample_domains[count % len(sample_domains)]
            
            report = process_traffic(traffic, ip_blacklist, domain_blacklist, sample_domain)
            
            count += 1
            
            # Print summary (full report only for detected proxy)
            if "PROXY" in report['classification']:
                print(f"[{count}] 🚨 {report['classification']} - Risk: {report['final_risk_score']}")
                display_report(report)
            else:
                print(f"[{count}] ✓ {report['classification']} - Risk: {report['final_risk_score']}")
            
            time.sleep(1)
            
            # Optional: limit duration
            if duration > 0 and time.time() - start_time > duration:
                break
    
    except KeyboardInterrupt:
        print("\n[!] Monitoring stopped by user")
    
    print()
    show_statistics()


if __name__ == "__main__":
    """
    Main execution entry point
    
    Usage:
        python main.py              # Run demo (5 samples)
        python main.py --continuous # Run continuous monitoring
        python main.py --stats      # Show statistics only
    """
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "--continuous":
            run_continuous_monitoring(duration=0)
        elif sys.argv[1] == "--stats":
            show_statistics()
        else:
            print(f"Usage: python main.py [--continuous|--stats]")
    else:
        run_demo()
