"""
Configuration File for Anti-Proxy Detection System
VGU (Vivekananda Global University)

This file contains all configuration settings for the system
"""

# File paths for data and logs
LOG_FILE = "data/logs.csv"
IP_BLACKLIST_FILE = "data/proxy_ip_list.txt"
DOMAIN_BLACKLIST_FILE = "data/proxy_domains.txt"

# Risk scoring threshold
# If risk_score >= RISK_THRESHOLD, traffic is flagged as PROXY/VPN
RISK_THRESHOLD = 70

# System settings
DEBUG_MODE = True
SYSTEM_NAME = "VGU Anti-Proxy Detection System v1.0"
