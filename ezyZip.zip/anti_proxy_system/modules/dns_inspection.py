"""
DNS Inspection Module

Purpose:
- Analyze DNS queries
- Detect queries to known proxy/VPN domains
- Flag suspicious domain requests

DNS inspection helps identify proxy services that might be
accessible via domain names (e.g., vpn-service.com, proxy-rental.net)
"""


def load_domain_blacklist(path):
    """
    Load domain blacklist from file
    
    File format: One domain per line
    Example:
        nordvpn.com
        expressvpn.com
        proxy-rental.net
    
    Args:
        path (str): Path to domain blacklist file
    
    Returns:
        list: List of blacklisted domains
    """
    try:
        with open(path, "r") as file:
            domains = [line.strip().lower() for line in file.readlines() if line.strip()]
        return domains
    except FileNotFoundError:
        print(f"Warning: Domain blacklist file not found at {path}")
        return []


def check_domain(domain, domain_blacklist):
    """
    Check if domain is in blacklist
    
    Case-insensitive matching
    
    Args:
        domain (str): Domain name to check
        domain_blacklist (list): List of blacklisted domains
    
    Returns:
        bool: True if domain is blacklisted
    """
    domain_lower = domain.lower()
    
    for bad_domain in domain_blacklist:
        # Exact match
        if domain_lower == bad_domain:
            return True
        # Substring match (catches subdomains)
        if bad_domain in domain_lower:
            return True
    
    return False


def get_dns_risk_score(domain, domain_blacklist):
    """
    Get risk score based on DNS query
    
    Args:
        domain (str): Domain being queried
        domain_blacklist (list): List of blacklisted domains
    
    Returns:
        int: Risk score (0-100)
    """
    if check_domain(domain, domain_blacklist):
        return 40  # Medium-high risk
    return 0


def extract_domain_from_query(query_string):
    """
    Extract domain name from DNS query string
    
    Args:
        query_string (str): DNS query (e.g., "my-vpn-service.com")
    
    Returns:
        str: Extracted domain name
    """
    # Remove leading/trailing spaces and convert to lowercase
    return query_string.strip().lower()


# For debugging purposes
if __name__ == "__main__":
    print("=== DNS Inspection Module ===")
    test_domains = ["nordvpn.com", "expressvpn.com"]
    test_query = "nordvpn.com"
    result = check_domain(test_query, test_domains)
    print(f"Is {test_query} blacklisted? {result}")
