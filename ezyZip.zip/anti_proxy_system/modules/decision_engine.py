"""
Rule-Based Decision Engine

Purpose:
- Aggregate all detection modules' scores
- Apply decision rules
- Classify traffic as NORMAL or PROXY/VPN
- Assign final risk score

This module makes the final decision based on:
1. IP reputation score
2. DNS inspection results
3. Behavioral analysis
4. ML prediction (if available)
"""


def calculate_risk_score(ip_score, dns_score, behavior_score, ml_score=0):
    """
    Calculate combined risk score from all modules
    
    Weighted combination:
    - IP Reputation: 40% weight
    - DNS Inspection: 30% weight
    - Behavior Analysis: 20% weight
    - ML Model: 10% weight
    
    Args:
        ip_score (int): Risk score from IP reputation (0-100)
        dns_score (int): Risk score from DNS inspection (0-100)
        behavior_score (int): Risk score from behavior analysis (0-100)
        ml_score (int): Risk score from ML model (0-100)
    
    Returns:
        int: Weighted combined risk score (0-100)
    """
    # Weighted calculation
    total_score = (
        (ip_score * 0.40) +
        (dns_score * 0.30) +
        (behavior_score * 0.20) +
        (ml_score * 0.10)
    )
    
    # Ensure score is between 0 and 100
    return min(100, max(0, int(total_score)))


def decide_traffic_classification(risk_score, threshold):
    """
    Classify traffic as NORMAL or PROXY/VPN
    
    Args:
        risk_score (int): Combined risk score (0-100)
        threshold (int): Decision threshold (default 70)
    
    Returns:
        str: Classification ("NORMAL" or "PROXY/VPN")
    """
    if risk_score >= threshold:
        return "PROXY/VPN DETECTED"
    return "NORMAL TRAFFIC"


def get_action(classification):
    """
    Determine action based on classification
    
    Args:
        classification (str): Traffic classification
    
    Returns:
        str: Action to take (ALLOW, WARN, BLOCK)
    """
    if classification == "PROXY/VPN DETECTED":
        return "WARN"  # For lab environment, we warn instead of blocking
    return "ALLOW"


def generate_decision_report(traffic_data, scores, risk_score, threshold):
    """
    Generate detailed decision report
    
    Args:
        traffic_data (dict): Traffic metadata
        scores (dict): Individual module scores
        risk_score (int): Final risk score
        threshold (int): Decision threshold
    
    Returns:
        dict: Comprehensive decision report
    """
    classification = decide_traffic_classification(risk_score, threshold)
    action = get_action(classification)
    
    report = {
        "source_ip": traffic_data.get("src_ip"),
        "destination_ip": traffic_data.get("dst_ip"),
        "protocol": traffic_data.get("protocol"),
        "ip_score": scores.get("ip_score", 0),
        "dns_score": scores.get("dns_score", 0),
        "behavior_score": scores.get("behavior_score", 0),
        "ml_score": scores.get("ml_score", 0),
        "final_risk_score": risk_score,
        "classification": classification,
        "action": action,
        "timestamp": traffic_data.get("timestamp"),
        "reason": scores.get("reason", "")
    }
    
    return report


# For debugging purposes
if __name__ == "__main__":
    print("=== Decision Engine Module ===")
    
    # Test case 1: Normal traffic
    score1 = calculate_risk_score(0, 0, 0, 0)
    print(f"Normal traffic score: {score1} → {decide_traffic_classification(score1, 70)}")
    
    # Test case 2: Suspicious traffic
    score2 = calculate_risk_score(60, 40, 30, 50)
    print(f"Suspicious traffic score: {score2} → {decide_traffic_classification(score2, 70)}")
    
    # Test case 3: Detected proxy
    score3 = calculate_risk_score(65, 40, 35, 0)
    print(f"Proxy detected score: {score3} → {decide_traffic_classification(score3, 70)}")
