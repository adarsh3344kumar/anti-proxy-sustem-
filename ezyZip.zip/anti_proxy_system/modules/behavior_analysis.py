"""
Traffic Behavior Analysis Module

Purpose:
- Analyze traffic patterns to detect anomalies
- Calculate packet size averages
- Measure session duration
- Identify suspicious behavior patterns

VPN/Proxy traffic often exhibits different patterns:
- Uniform packet sizes (encryption)
- Consistent data rates
- Long continuous sessions
"""


def analyze_packet_size(packet_size):
    """
    Analyze packet size for suspicious patterns
    
    VPN traffic often has uniform packet sizes due to encryption
    Normal web traffic varies more in packet size
    
    Args:
        packet_size (int): Size of packet in bytes
    
    Returns:
        int: Risk score (0-100)
    """
    # Suspicious if packet size is very large (typical VPN behavior)
    if packet_size > 1300:
        return 30  # Moderate risk
    
    # Normal web traffic
    return 0


def calculate_average_packet_size(packet_sizes):
    """
    Calculate average packet size from list
    
    Args:
        packet_sizes (list): List of packet sizes
    
    Returns:
        float: Average packet size
    """
    if not packet_sizes:
        return 0
    return sum(packet_sizes) / len(packet_sizes)


def analyze_session_duration(session_duration):
    """
    Analyze session duration for anomalies
    
    Very long sessions might indicate persistent proxy/VPN usage
    
    Args:
        session_duration (float): Session duration in seconds
    
    Returns:
        int: Risk score (0-100)
    """
    # Sessions > 1 hour might be suspicious if continuous
    if session_duration > 3600:
        return 20
    
    return 0


def detect_data_rate_anomaly(bytes_sent, bytes_received, duration):
    """
    Detect anomalous data transfer rates
    
    Args:
        bytes_sent (int): Bytes sent
        bytes_received (int): Bytes received
        duration (float): Duration in seconds
    
    Returns:
        int: Risk score
    """
    if duration == 0:
        return 0
    
    data_rate = (bytes_sent + bytes_received) / duration
    
    # Abnormally high data rate
    if data_rate > 10000000:  # > 10 MB/s
        return 25
    
    return 0


def analyze_traffic_pattern(traffic_list):
    """
    Comprehensive analysis of traffic pattern
    
    Args:
        traffic_list (list): List of traffic dictionaries
    
    Returns:
        dict: Analysis results with risk score
    """
    if not traffic_list:
        return {"risk_score": 0, "reason": "No traffic data"}
    
    packet_sizes = [t.get("packet_size", 0) for t in traffic_list]
    avg_size = calculate_average_packet_size(packet_sizes)
    
    # Check if packet sizes are suspiciously uniform
    if packet_sizes:
        variance = sum((x - avg_size) ** 2 for x in packet_sizes) / len(packet_sizes)
        
        # Low variance suggests VPN/Proxy encryption
        if variance < 10000:
            return {
                "risk_score": 35,
                "reason": "Uniform packet size pattern (encryption indicator)"
            }
    
    return {"risk_score": 0, "reason": "Normal traffic pattern"}


# For debugging purposes
if __name__ == "__main__":
    print("=== Behavior Analysis Module ===")
    print(f"Packet size 1500 risk: {analyze_packet_size(1500)}")
    print(f"Packet size 800 risk: {analyze_packet_size(800)}")
    print(f"Session 2 hours risk: {analyze_session_duration(7200)}")
