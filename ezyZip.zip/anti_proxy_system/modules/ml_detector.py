"""
Machine Learning Detector Module (Optional)

Purpose:
- Extract features from traffic data
- Apply simple ML models
- Predict if traffic is normal or proxy/VPN

Supported Models:
- Random Forest
- Logistic Regression

Note: This module is optional and for enhanced detection
For lab purposes, we provide a simplified implementation
"""


class MLDetector:
    """Machine Learning based proxy detector"""
    
    def __init__(self, model_type="random_forest"):
        """
        Initialize ML detector
        
        Args:
            model_type (str): Type of model ("random_forest" or "logistic_regression")
        """
        self.model_type = model_type
        self.model = None
        self.is_trained = False
    
    def extract_features(self, traffic_data):
        """
        Extract features from traffic data
        
        Features extracted:
        - packet_size
        - protocol_type (TCP=1, UDP=0)
        - hour_of_day
        - is_large_packet
        - is_external_ip
        
        Args:
            traffic_data (dict): Traffic metadata
        
        Returns:
            list: Feature vector [packet_size, protocol, hour, large_pkt, external]
        """
        # Extract packet size
        packet_size = traffic_data.get("packet_size", 0)
        
        # Encode protocol
        protocol = traffic_data.get("protocol", "TCP")
        protocol_code = 1 if protocol == "TCP" else 0
        
        # Extract hour
        from datetime import datetime
        hour = datetime.fromtimestamp(traffic_data.get("timestamp", 0)).hour
        
        # Is large packet?
        is_large = 1 if packet_size > 1300 else 0
        
        # Is external IP?
        dst_ip = traffic_data.get("dst_ip", "")
        is_external = 1 if not dst_ip.startswith("192.168") else 0
        
        features = [packet_size, protocol_code, hour, is_large, is_external]
        return features
    
    def predict_dummy(self, features):
        """
        Dummy ML prediction (for lab/demo purposes)
        
        This is a simplified rule-based predictor
        In production, this would use a trained model
        
        Args:
            features (list): Feature vector
        
        Returns:
            int: Prediction (0=NORMAL, 1=PROXY)
        """
        packet_size, protocol, hour, is_large, is_external = features
        
        # Simple heuristic rules
        score = 0
        
        if is_large:
            score += 30
        
        if is_external and packet_size > 1000:
            score += 25
        
        if protocol == 0:  # UDP often used by VPN
            score += 15
        
        # Predict proxy if score > 50
        return 1 if score > 50 else 0
    
    def predict_random_forest(self, features):
        """
        Predict using Random Forest model
        
        Requires: sklearn package
        For lab use: uses dummy implementation
        
        Args:
            features (list): Feature vector
        
        Returns:
            int: Prediction (0=NORMAL, 1=PROXY)
        """
        try:
            from sklearn.ensemble import RandomForestClassifier  # type: ignore
            # In production, load trained model from disk
            # model = joblib.load('trained_model.pkl')
            # return model.predict([features])[0]
            
        except ImportError:
            pass
        
        # Fallback to dummy prediction
        return self.predict_dummy(features)
    
    def predict_logistic_regression(self, features):
        """
        Predict using Logistic Regression model
        
        Requires: sklearn package
        For lab use: uses dummy implementation
        
        Args:
            features (list): Feature vector
        
        Returns:
            int: Prediction (0=NORMAL, 1=PROXY)
        """
        try:
            from sklearn.linear_model import LogisticRegression  # type: ignore
            # In production, load trained model from disk
            # model = joblib.load('trained_lr_model.pkl')
            # return model.predict([features])[0]
            
        except ImportError:
            pass
        
        # Fallback to dummy prediction
        return self.predict_dummy(features)
    
    def predict(self, traffic_data):
        """
        Make prediction for traffic data
        
        Args:
            traffic_data (dict): Traffic metadata
        
        Returns:
            dict: Prediction result with confidence
        """
        features = self.extract_features(traffic_data)
        
        if self.model_type == "random_forest":
            prediction = self.predict_random_forest(features)
        elif self.model_type == "logistic_regression":
            prediction = self.predict_logistic_regression(features)
        else:
            prediction = self.predict_dummy(features)
        
        # Convert prediction to risk score
        risk_score = 80 if prediction == 1 else 0
        
        return {
            "model": self.model_type,
            "prediction": prediction,
            "risk_score": risk_score,
            "predicted_class": "PROXY" if prediction == 1 else "NORMAL"
        }


# Convenience function
def ml_predict(traffic_data, model_type="random_forest"):
    """
    Simplified ML prediction function
    
    Args:
        traffic_data (dict): Traffic metadata
        model_type (str): Type of model to use
    
    Returns:
        int: Risk score (0-100)
    """
    detector = MLDetector(model_type)
    result = detector.predict(traffic_data)
    return result["risk_score"]


# For debugging purposes
if __name__ == "__main__":
    print("=== ML Detector Module ===")
    
    # Test feature extraction
    sample_traffic = {
        "packet_size": 1500,
        "protocol": "TCP",
        "dst_ip": "45.142.120.1",
        "timestamp": 1702000000
    }
    
    detector = MLDetector()
    features = detector.extract_features(sample_traffic)
    print(f"Extracted features: {features}")
    
    # Test prediction
    result = detector.predict(sample_traffic)
    print(f"ML Prediction: {result}")
