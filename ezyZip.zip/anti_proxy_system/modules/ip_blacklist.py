"""
IP Reputation & Blacklist Module

Purpose: 
- Load known proxy/VPN IP addresses/ranges
- Check if destination IP is in blacklist
- Assign risk score based on IP reputation

This is a defensive mechanism to identify traffic going through
known proxy/VPN providers
"""


def load_blacklist(path):
    """
    Load IP blacklist from file
    
    File format: One IP per line
    Example:
        45.142.120.1
        45.142.120.2
        206.189.45.1
    
    Args:
        path (str): Path to the blacklist file
    
    Returns:
        list: List of blacklisted IP addresses
    """
    try:
        with open(path, "r") as file:
            blacklist = [line.strip() for line in file.readlines() if line.strip()]
        return blacklist
    except FileNotFoundError:
        print(f"Warning: Blacklist file not found at {path}")
        return []


def check_ip(ip, blacklist):
    """
    Check if IP address is in blacklist
    
    Args:
        ip (str): IP address to check
        blacklist (list): List of blacklisted IPs
    
    Returns:
        bool: True if IP is blacklisted, False otherwise
    """
    return ip in blacklist


def check_ip_range(ip, blacklist_ranges):
    """
    Check if IP falls within blacklisted IP ranges
    
    Useful for checking CIDR ranges like 45.142.120.0/24
    
    Args:
        ip (str): IP address to check
        blacklist_ranges (list): List of IP ranges in CIDR notation
    
    Returns:
        bool: True if IP is in blacklisted range
    """
    # This is a simplified version
    # For production, use: python -m pip install ipaddress
    
    ip_parts = ip.split(".")
    for range_cidr in blacklist_ranges:
        if range_cidr in ip:  # Simple substring match for lab purposes
            return True
    return False


def get_ip_reputation_score(ip, blacklist):
    """
    Get risk score for an IP address
    
    Args:
        ip (str): IP address to check
        blacklist (list): List of blacklisted IPs
    
    Returns:
        int: Risk score (0-100)
    """
    if check_ip(ip, blacklist):
        return 60  # High risk
    return 0


# For debugging purposes
if __name__ == "__main__":
    print("=== IP Blacklist Module ===")
    # Test blacklist
    test_blacklist = ["45.142.120.1", "206.189.45.1"]
    test_ip = "45.142.120.1"
    result = check_ip(test_ip, test_blacklist)
    print(f"Is {test_ip} blacklisted? {result}")
