"""
Traffic Monitoring Module
Simulates network packet capture (metadata only)

Purpose: Captures network traffic metadata
- Source IP
- Destination IP
- Protocol (TCP/UDP)
- Packet size
- Timestamp

NOTE: Payload/Content is NOT captured → Privacy safe
This is a simulation for lab/educational purposes
"""

import random
import time


def capture_traffic():
    """
    Simulates network metadata capture
    
    In a real scenario, this would use:
    - scapy (for packet sniffing)
    - pyshark (for network analysis)
    - tcpdump (system-level packet capture)
    
    For this lab simulation, we generate realistic traffic patterns
    
    Returns:
        dict: Traffic metadata with keys:
            - src_ip: Source IP address
            - dst_ip: Destination IP address
            - protocol: TCP or UDP
            - packet_size: Packet size in bytes
            - timestamp: Unix timestamp
    """
    
    # Generate synthetic traffic
    traffic = {
        "src_ip": f"192.168.1.{random.randint(2, 100)}",          # Internal campus network
        "dst_ip": f"45.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}",  # External IP
        "protocol": random.choice(["TCP", "UDP"]),
        "packet_size": random.randint(200, 1500),                 # Typical packet size
        "timestamp": time.time()                                  # Current timestamp
    }
    
    return traffic


def capture_multiple_traffic(count=1):
    """
    Capture multiple traffic samples
    
    Args:
        count (int): Number of traffic samples to capture
    
    Returns:
        list: List of traffic dictionaries
    """
    return [capture_traffic() for _ in range(count)]


# For debugging purposes
if __name__ == "__main__":
    print("=== Traffic Monitor Module ===")
    sample = capture_traffic()
    print("Sample traffic captured:")
    for key, value in sample.items():
        print(f"  {key}: {value}")
