"""
Logging Module

Purpose:
- Store detection events with metadata
- Hash IP addresses for privacy protection
- Save logs to CSV file or database
- Support audit trails

All IP addresses are hashed using SHA-256 for privacy
This ensures compliance with data protection regulations
"""

import csv
import hashlib
from datetime import datetime
import os


def hash_ip(ip_address):
    """
    Hash IP address using SHA-256
    
    This protects user privacy while allowing pattern detection
    The hashed value cannot be reversed to get the original IP
    
    Args:
        ip_address (str): IP address to hash
    
    Returns:
        str: SHA-256 hashed IP address
    """
    return hashlib.sha256(ip_address.encode()).hexdigest()


def create_log_entry(timestamp, src_ip, dst_ip, protocol, classification, risk_score, reason=""):
    """
    Create a single log entry
    
    Args:
        timestamp (float): Unix timestamp
        src_ip (str): Source IP (will be hashed)
        dst_ip (str): Destination IP (will be hashed)
        protocol (str): Protocol used
        classification (str): NORMAL or PROXY/VPN DETECTED
        risk_score (int): Risk score (0-100)
        reason (str): Reason for classification
    
    Returns:
        list: Log entry as list (for CSV writing)
    """
    formatted_time = datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
    
    entry = [
        formatted_time,
        hash_ip(src_ip),
        hash_ip(dst_ip),
        protocol,
        classification,
        risk_score,
        reason
    ]
    
    return entry


def write_log_entry(log_file, src_ip, dst_ip, protocol, classification, risk_score, reason=""):
    """
    Write a single log entry to file
    
    Creates file if it doesn't exist, adds header row on first write
    
    Args:
        log_file (str): Path to log file
        src_ip (str): Source IP
        dst_ip (str): Destination IP
        protocol (str): Protocol
        classification (str): Classification result
        risk_score (int): Risk score
        reason (str): Reason for classification
    """
    # Check if file exists to determine if we need to write header
    file_exists = os.path.isfile(log_file)
    
    # Ensure directory exists
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    with open(log_file, "a", newline="") as file:
        writer = csv.writer(file)
        
        # Write header on first write
        if not file_exists:
            writer.writerow([
                "Timestamp",
                "Source IP (Hashed)",
                "Destination IP (Hashed)",
                "Protocol",
                "Classification",
                "Risk Score",
                "Reason"
            ])
        
        # Write log entry
        entry = create_log_entry(
            datetime.now().timestamp(),
            src_ip,
            dst_ip,
            protocol,
            classification,
            risk_score,
            reason
        )
        writer.writerow(entry)


def log_detection_event(log_file, traffic_data, decision_report):
    """
    Log a detection event from decision report
    
    Args:
        log_file (str): Path to log file
        traffic_data (dict): Original traffic data
        decision_report (dict): Decision report with results
    """
    write_log_entry(
        log_file,
        traffic_data.get("src_ip"),
        traffic_data.get("dst_ip"),
        traffic_data.get("protocol"),
        decision_report.get("classification"),
        decision_report.get("final_risk_score"),
        decision_report.get("reason", "")
    )


def read_logs(log_file, limit=None):
    """
    Read logs from file
    
    Args:
        log_file (str): Path to log file
        limit (int): Maximum number of entries to read (None for all)
    
    Returns:
        list: List of log entries (excluding header)
    """
    if not os.path.exists(log_file):
        return []
    
    with open(log_file, "r") as file:
        reader = csv.reader(file)
        entries = list(reader)
    
    # Skip header and limit results
    if entries:
        entries = entries[1:]  # Skip header
        if limit:
            entries = entries[-limit:]  # Get last N entries
    
    return entries


def get_log_statistics(log_file):
    """
    Get statistics from logs
    
    Args:
        log_file (str): Path to log file
    
    Returns:
        dict: Statistics dictionary
    """
    logs = read_logs(log_file)
    
    if not logs:
        return {
            "total_events": 0,
            "proxy_detected": 0,
            "normal_traffic": 0
        }
    
    proxy_count = sum(1 for log in logs if "PROXY" in log[4])
    normal_count = len(logs) - proxy_count
    
    return {
        "total_events": len(logs),
        "proxy_detected": proxy_count,
        "normal_traffic": normal_count,
        "detection_rate": f"{(proxy_count/len(logs)*100):.2f}%" if logs else "0%"
    }


# For debugging purposes
if __name__ == "__main__":
    print("=== Logger Module ===")
    
    # Test hashing
    test_ip = "192.168.1.100"
    hashed = hash_ip(test_ip)
    print(f"Original IP: {test_ip}")
    print(f"Hashed IP: {hashed}")
    
    # Test logging
    print("\nTesting log write...")
    write_log_entry(
        "test_logs.csv",
        "192.168.1.50",
        "45.142.120.1",
        "TCP",
        "PROXY/VPN DETECTED",
        75,
        "Blacklisted IP detected"
    )
    print("Log entry written successfully!")
