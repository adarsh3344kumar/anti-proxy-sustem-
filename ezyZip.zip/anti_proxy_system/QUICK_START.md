# 🚀 QUICK START GUIDE

**VGU Anti-Proxy Detection System - 30 Second Setup**

---

## ⚡ Installation (2 minutes)

### Step 1: Install Python Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Run Demo
```bash
python main.py
```

You'll see:
- ✅ System initialization
- ✅ 5 traffic samples analyzed
- ✅ Detection results
- ✅ Statistics

---

## 🎮 Try Different Modes

### Mode 1: Demo (5 Samples)
```bash
python main.py
```

### Mode 2: Continuous Monitoring
```bash
python main.py --continuous
```
(Press Ctrl+C to stop)

### Mode 3: View Statistics
```bash
python main.py --stats
```

---

## 🖥️ Launch Web Dashboard

```bash
cd dashboard
python app.py
```

Then open: **http://localhost:5000**

---

## 📁 File Structure

**What Each Directory Contains:**

- **`main.py`** → System controller (run this!)
- **`config.py`** → Settings (edit to customize)
- **`modules/`** → Detection modules (all the logic)
- **`dashboard/`** → Web interface
- **`data/`** → Blacklists & logs
- **`requirements.txt`** → Python packages needed

---

## 🔧 Customization

### Change Risk Threshold
Edit `config.py`:
```python
RISK_THRESHOLD = 70  # Change this value (0-100)
```

### Add More Blacklisted IPs
Edit `data/proxy_ip_list.txt`:
```
45.142.120.1
45.142.120.2
YOUR.IP.HERE
```

### Add More Proxy Domains
Edit `data/proxy_domains.txt`:
```
nordvpn.com
expressv
```

---

## 🎓 Understanding the Output

### Sample Output:
```
Source IP (Hashed)      : 192.168...
Destination IP          : 45.142.120.1
Protocol                : TCP

IP Reputation Score     : 60/100      ← Blacklist hit
DNS Inspection Score    : 0/100       ← Not a proxy domain
Behavior Analysis Score : 30/100      ← Large packet
ML Model Score          : 0/100       ← Normal pattern

FINAL RISK SCORE        : 42/100      ← Combined score
Classification          : NORMAL TRAFFIC  ← Decision
Recommended Action      : ALLOW       ← Action taken
```

---

## 📊 What Gets Logged?

View `data/logs.csv`:
```csv
Timestamp,Source IP (Hashed),Destination IP (Hashed),Protocol,Classification,Risk Score
2024-02-10 10:30:45,a1b2c3d4...,e5f6g7h8...,TCP,PROXY/VPN DETECTED,75
```

**IPs are hashed for privacy!** ✅

---

## 🎯 Common Tasks

### Task 1: Test With Sample IP
1. Add test IP to `data/proxy_ip_list.txt`
2. Run `python main.py`
3. Check logs

### Task 2: Monitor All Traffic
1. Run `python main.py --continuous`
2. Watch real-time analysis
3. Check dashboard at http://localhost:5000

### Task 3: Analyze Statistics
1. Run `python main.py --stats`
2. See total events, detections, rate

---

## ❓ FAQ

**Q: Can I modify detection rules?**
A: Yes! Edit modules in `modules/` folder

**Q: Is real traffic captured?**
A: No, this is simulation for lab purposes

**Q: Where are logs saved?**
A: In `data/logs.csv` (hashed for privacy)

**Q: Can I add more ML models?**
A: Yes! Modify `modules/ml_detector.py`

**Q: Is this for production?**
A: No, it's for educational lab purposes only

---

## 📖 Next Steps

1. **Learn Module Structure** → Read `README.md`
2. **Try Different Scenarios** → Edit `config.py`
3. **Enhance Detection** → Modify modules
4. **Build Dashboard** → Extend `dashboard/`

---

## 🎓 For College Projects

This system demonstrates:
- ✅ Modular Python architecture
- ✅ Network traffic analysis
- ✅ Security detection mechanisms
- ✅ Web dashboard development
- ✅ Privacy-preserving logging
- ✅ Machine learning integration
- ✅ Defensive cybersecurity

**Perfect for:**
- Semester projects
- Lab assignments
- Portfolio demonstration
- Internship preparation

---

**Happy Learning! 🛡️**

For more details → See `README.md`
